package org.example.examen.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.UUID;

@Entity @Data
public class Pelicula {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private String titulo;
    private Integer anyoEstreno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "director_id")
    private Director director;
}