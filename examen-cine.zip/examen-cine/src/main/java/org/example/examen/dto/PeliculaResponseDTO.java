package org.example.examen.dto;
import lombok.Data;
import java.util.UUID;
import java.util.List;

@Data
public class PeliculaResponseDTO {
    private UUID id;
    private String titulo;
    private String nombreDirector;
    private List<String> nombresGeneros;
}