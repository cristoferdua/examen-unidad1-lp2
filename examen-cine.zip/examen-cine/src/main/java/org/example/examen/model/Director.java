package org.example.examen.model;
import jakarta.persistence.*;
import lombok.Data;
import java.util.UUID;

@Entity @Data
public class Director {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(nullable = false, unique = true)
    private String nombre;
    private String nacionalidad;
}