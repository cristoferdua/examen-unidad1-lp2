package org.example.examen.service;

import lombok.RequiredArgsConstructor;
import org.example.examen.dto.PeliculaRequestDTO;
import org.example.examen.dto.PeliculaResponseDTO;
import org.example.examen.mapper.PeliculaMapper;
import org.example.examen.model.Director;
import org.example.examen.model.Genero;
import org.example.examen.model.Pelicula;
import org.example.examen.model.PeliculaGenero;
import org.example.examen.repository.DirectorRepository;
import org.example.examen.repository.GeneroRepository;
import org.example.examen.repository.PeliculaGeneroRepository;
import org.example.examen.repository.PeliculaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PeliculaService {

    // ESTO ES LO QUE TE FALTA (Las declaraciones de las variables)
    private final PeliculaRepository peliculaRepo;
    private final DirectorRepository directorRepo;
    private final GeneroRepository generoRepo;
    private final PeliculaGeneroRepository pgRepo;
    private final PeliculaMapper mapper;

    @Transactional
    public PeliculaResponseDTO guardarConGeneros(PeliculaRequestDTO dto) {
        // 1. Obtener Director
        Director dir = directorRepo.findById(dto.getDirectorId())
                .orElseThrow(() -> new RuntimeException("Director no encontrado"));

        // 2. Crear Película
        Pelicula p = new Pelicula();
        p.setTitulo(dto.getTitulo());
        p.setAnyoEstreno(dto.getAnyoEstreno());
        p.setDirector(dir);

        Pelicula guardada = peliculaRepo.save(p);

        // 3. Tabla intermedia y nombres de géneros
        List<String> nombresGeneros = dto.getGeneroIds().stream().map(gId -> {
            Genero g = generoRepo.findById(gId)
                    .orElseThrow(() -> new RuntimeException("Género no encontrado"));

            PeliculaGenero pg = new PeliculaGenero();
            pg.setPelicula(guardada);
            pg.setGenero(g);
            pgRepo.save(pg);

            return g.getNombre();
        }).collect(Collectors.toList());

        // 4. Mapear respuesta
        PeliculaResponseDTO res = mapper.toResponseDTO(guardada);
        res.setNombresGeneros(nombresGeneros);

        return res;
    }
}