package org.example.examen.mapper;

import org.example.examen.dto.PeliculaResponseDTO;
import org.example.examen.model.Pelicula;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PeliculaMapper {
    @Mapping(source = "director.nombre", target = "nombreDirector")
    @Mapping(target = "nombresGeneros", ignore = true)
    PeliculaResponseDTO toResponseDTO(Pelicula pelicula);
}