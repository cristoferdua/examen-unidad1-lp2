package org.example.examen.controller;
import lombok.RequiredArgsConstructor;
import org.example.examen.dto.*;
import org.example.examen.service.PeliculaService;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/peliculas") @RequiredArgsConstructor
public class PeliculaController {
    private final PeliculaService service;

    @PostMapping("/con-generos")
    public PeliculaResponseDTO crear(@RequestBody PeliculaRequestDTO dto) {
        return service.guardarConGeneros(dto);
    }
}