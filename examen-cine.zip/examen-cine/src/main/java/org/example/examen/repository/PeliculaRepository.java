package org.example.examen.repository;

import org.example.examen.model.Pelicula;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public interface PeliculaRepository extends JpaRepository<Pelicula, UUID> {
}