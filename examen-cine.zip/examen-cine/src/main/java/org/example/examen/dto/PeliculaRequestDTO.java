package org.example.examen.dto;
import lombok.Data;
import java.util.UUID;
import java.util.List;

@Data
public class PeliculaRequestDTO {
    private String titulo;
    private Integer anyoEstreno;
    private UUID directorId;
    private List<UUID> generoIds; // Lista de IDs para el endpoint estrella
}