package org.example.examen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenCineApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamenCineApplication.class, args);
    }

}
