package org.example.examen.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.UUID;

@Entity @Data
public class PeliculaGenero {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    private Pelicula pelicula;

    @ManyToOne(fetch = FetchType.LAZY)
    private Genero genero;
}