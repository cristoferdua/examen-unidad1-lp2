package org.example.examen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenCineApplicationTests {

    @Test
    void contextLoads() {
    }

}
