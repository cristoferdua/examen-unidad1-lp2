plugins {
    java
    id("org.springframework.boot") version "4.0.5"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "org.example"
version = "0.0.1-SNAPSHOT"
description = "examen-cine"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
}

repositories {
    mavenCentral()
}

dependencies {
    dependencies {
        implementation("org.springframework.boot:spring-boot-starter-data-jpa")
        implementation("org.springframework.boot:spring-boot-starter-web")
        implementation("org.springframework.boot:spring-boot-starter-validation")

        // LOMBOK
        compileOnly("org.projectlombok:lombok")
        annotationProcessor("org.projectlombok:lombok")
        runtimeOnly("org.postgresql:postgresql")
        implementation("org.mapstruct:mapstruct:1.5.5.Final")
        annotationProcessor("org.mapstruct:mapstruct-processor:1.5.5.Final")
        annotationProcessor("org.projectlombok:lombok-mapstruct-binding:0.2.0")

        testImplementation("org.springframework.boot:spring-boot-starter-test")
        dependencies {
            compileOnly("org.projectlombok:lombok")
            annotationProcessor("org.projectlombok:lombok")
            implementation("org.mapstruct:mapstruct:1.5.5.Final")
            annotationProcessor("org.mapstruct:mapstruct-processor:1.5.5.Final")
            annotationProcessor("org.projectlombok:lombok-mapstruct-binding:0.2.0")
        }
    }
}

tasks.withType<Test> {
    useJUnitPlatform()
}
tasks.withType<JavaCompile> {
    options.compilerArgs.add("-Amapstruct.defaultComponentModel=spring")
}
